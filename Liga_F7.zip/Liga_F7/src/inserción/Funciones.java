package inserci�n;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Clases.Equipo;
import Clases.Jugador;
import Pruebas.Main;

public class Funciones extends ClaseDAO{
	
	public Funciones() {
		super();
	}

	public String leerPartido(int id){
		String s = null;
		printEquiposCompetici�n(id);
		int id_partido = 0;
		Equipo Equipo_L = Main.seleccionaEquipo();
		Equipo Equipo_V = Main.seleccionaEquipo();
		String sql = "SELECT id FROM Partidos WHERE Equipo_Local = ? AND Equipo_Visitante = ?";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setString(1, Equipo_L.getNombre());
			sentencia.setString(2, Equipo_V.getNombre());
			ResultSet rs = sentencia.executeQuery();
			if(rs.next()) id_partido = rs.getInt(1);
			String sql2 = "SELECT * FROM Stats WHERE Id_partido = "+id_partido;
			PreparedStatement sentencia2 = con.prepareStatement(sql2);
			ResultSet rs2 = sentencia2.executeQuery();
			int golesL = 0;
			int golesV = 0;
			int num_jugador;
			JugadoresDAO j = new JugadoresDAO();
			Jugador jug;
			while(rs2.next()) {
				num_jugador = rs2.getInt(4);
				jug = j.read(num_jugador);
				if(jug.getE().equals(Equipo_L)) {
					golesL+=rs2.getInt(1);
				}
				else golesV+=rs2.getInt(1);
			}
			s = Equipo_L.getNombre()+" "+golesL+" - "+golesV+" "+Equipo_V.getNombre();
		} catch (SQLException e) {
			System.out.println("Error");
		}
		return s;
	}
	
	/**
	 * Funci�n que imprime por pantalla los equipos de la competici�n pasada como par�metro
	 * @param id
	 */
	public void printEquiposCompetici�n(int id) {
		String sql = "SELECT * FROM Participan WHERE ID_competicion = "+id;
		int cont = 0;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			while(rs.next()) {
				System.out.print(rs.getString(1)+"               \t\t");
				cont++;
				if(cont%3==0) System.out.println();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

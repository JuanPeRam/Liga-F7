package inserci�n;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Clases.Jugador;
import Pruebas.Main;

public class JugadoresDAO extends ClaseDAO{
	
	public JugadoresDAO() {
		super();
	}
	
	public Jugador read(int id) {
		Jugador j = null;
		String sql = "SELECT * FROM Jugadores WHERE Id = ?";
		try {
			PreparedStatement sentencia = super.con.prepareStatement(sql);
			sentencia.setInt(1, id);
			ResultSet rs = sentencia.executeQuery();
			if(rs.next()) {
				j = new Jugador(rs.getInt("Id"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Nombre_Equipo")),rs.getString("Temporada"));
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return j;
	}
	
	public ArrayList<Jugador> readAll(){
		ArrayList<Jugador> eqs = new ArrayList<>();
		Jugador j = null;
		String sql = "SELECT * FROM Jugadores";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			while(rs.next()) {
			j = new Jugador(rs.getInt("Id"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Nombre_Equipo")),rs.getString("Temporada"));
			eqs.add(j);
			Main.Jugadores.put(j.getId(), j);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return eqs;
	}

}

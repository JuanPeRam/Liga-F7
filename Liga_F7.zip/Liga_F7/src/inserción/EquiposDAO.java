package inserci�n;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Clases.Equipo;
import Pruebas.Main;

public class EquiposDAO extends ClaseDAO{
	//Constructor
	public EquiposDAO() {
		super();
	}
	public Equipo read(String nombre) {
		Equipo e = null;
		String sql = "SELECT * FROM Equipos WHERE Nombre = "+nombre;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			e = new Equipo(rs.getString("Nombre"),rs.getString("Procedencia"));
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return e;
	}
	public ArrayList<Equipo> readAll(){
		ArrayList<Equipo> eqs = new ArrayList<>();
		Equipo e = null;
		String sql = "SELECT * FROM Equipos";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			while(rs.next()) {
			e = new Equipo(rs.getString("Nombre"),rs.getString("Procedencia"));
			eqs.add(e);
			Main.Equipos.put(e.getNombre(), e);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return eqs;
	}
	
	public void create(Equipo e) {
		String sql = "INSERT INTO Equipos VALUES (?,?)";
		int num;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setString(1, e.getNombre());
			sentencia.setString(2, e.getProcedencia());
			num=sentencia.executeUpdate();
			if(num!=0) System.out.println("Equipo insertado con �xito");
		} catch (SQLException e1) {
			System.out.println("No se ha podido insertar el equipo");
		}
	}
}

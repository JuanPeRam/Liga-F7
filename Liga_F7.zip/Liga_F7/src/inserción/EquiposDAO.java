package inserci�n;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Clases.Equipo;

public class EquiposDAO {
	//Atributos
	private Connection con;
	private final String USUARIO = "root";
	private final String CONTRASE�A = "root";
	private final String MAQUINA = "localhost";
	private final String BD = "Liga_F7";
	//Constructor
	public EquiposDAO() {
		con = conectar();
	}
	//M�todos
	private Connection conectar() {
		Connection con = null;
		String url = "jdbc:mysql://"+MAQUINA+"/"+BD;
		try {
			con = DriverManager.getConnection(url, USUARIO, CONTRASE�A);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	public void cerrar() {
		if(this.con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public void create(Equipo e) {
		String sql = "INSERT INTO Equipos VALUES (?,?)";
		int num;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setString(1, e.getNombre());
			sentencia.setString(2, e.getProcedencia());
			System.out.println(sentencia);
			num=sentencia.executeUpdate();
			if(num!=0) System.out.println("Equipo insertado con �xito");
		} catch (SQLException e1) {
			System.out.println("No se ha podido insertar el equipo");
		}
	}
}

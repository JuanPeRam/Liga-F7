package inserci�n;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ClaseDAO {
	public Connection con;
	private final String USUARIO = "root";
	private final String CONTRASE�A = "root";
	private final String MAQUINA = "localhost";
	private final String BD = "Liga_F7";
	
	public ClaseDAO() {
		con = conectar();
	}
	
	private Connection conectar() {
		Connection con = null;
		String url = "jdbc:mysql://"+MAQUINA+"/"+BD;
		try {
			con = DriverManager.getConnection(url, USUARIO, CONTRASE�A);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public void cerrar() {
		if(this.con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

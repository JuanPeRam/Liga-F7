package inserci�n;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Clases.Competici�n;
import Pruebas.Main;

public class CompeticionesDAO extends ClaseDAO{
	
	public CompeticionesDAO() {
		super();
	}
	
	public Competici�n read(int id) {
		Competici�n c = null;
		String sql = "SELECT * FROM Competiciones WHERE Id = ?";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setInt(1, id);
			ResultSet rs = sentencia.executeQuery();
			if(rs.next()) {
				c = new Competici�n(rs.getInt("Id"),rs.getString("Temporada"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Ganador")));
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return c;
	}
	
	public ArrayList<Competici�n> readAll(){
		ArrayList<Competici�n> comps = new ArrayList<>();
		String sql = "SELECT * FROM Competiciones";
		Competici�n c;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			while(rs.next()) {
				c = new Competici�n(rs.getInt("Id"),rs.getString("Temporada"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Ganador")));
				comps.add(c);
				Main.Competiciones.put(c.getId(), c);
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return comps;
	}
	
	public void delete(int id) {
		String sql = "DELTE FROM COMPETICIONES WHERE ID = ?";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setInt(1, id);
			sentencia.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Error en el borrado de la competici�n");
		}
	}
}

package inserci�n;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Clases.Competici�n;

public class CompeticionesDAO {
	private Connection con;
	private final String USUARIO = "root";
	private final String CONTRASE�A = "root";
	private final String MAQUINA = "localhost";
	private final String BD = "Liga_F7";
	
	public CompeticionesDAO() {
		con = conectar();
	}

	private Connection conectar() {
		Connection con = null;
		String url = "jdbc:mysql://"+MAQUINA+"/"+BD;
		try {
			con = DriverManager.getConnection(url, USUARIO, CONTRASE�A);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public Competici�n read(int id) {
		Competici�n c = null;
		String sql = "SELECT * FROM Competiciones WHERE Id = ?";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setInt(1, id);
			ResultSet rs = sentencia.executeQuery();
			if(rs.next()) {
				c = new Competici�n(rs.getInt("Id"),rs.getString("Temporada"),rs.getString("Nombre"),rs.getString("Ganador"));
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return c;
	}
	public void cerrar() {
		if(this.con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

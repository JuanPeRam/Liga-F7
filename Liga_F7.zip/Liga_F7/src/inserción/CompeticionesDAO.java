package inserci�n;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Clases.Competici�n;
import Pruebas.Main;

public class CompeticionesDAO {
	private Connection con;
	private final String USUARIO = "root";
	private final String CONTRASE�A = "root";
	private final String MAQUINA = "localhost";
	private final String BD = "Liga_F7";
	
	public CompeticionesDAO() {
		con = conectar();
	}

	private Connection conectar() {
		Connection con = null;
		String url = "jdbc:mysql://"+MAQUINA+"/"+BD;
		try {
			con = DriverManager.getConnection(url, USUARIO, CONTRASE�A);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public Competici�n read(int id) {
		Competici�n c = null;
		String sql = "SELECT * FROM Competiciones WHERE Id = ?";
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			sentencia.setInt(1, id);
			ResultSet rs = sentencia.executeQuery();
			if(rs.next()) {
				c = new Competici�n(rs.getInt("Id"),rs.getString("Temporada"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Ganador")));
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return c;
	}
	
	public ArrayList<Competici�n> readAll(){
		ArrayList<Competici�n> comps = new ArrayList<>();
		String sql = "SELECT * FROM Competiciones";
		Competici�n c;
		try {
			PreparedStatement sentencia = con.prepareStatement(sql);
			ResultSet rs = sentencia.executeQuery();
			while(rs.next()) {
				c = new Competici�n(rs.getInt("Id"),rs.getString("Temporada"),rs.getString("Nombre"),Main.Equipos.get(rs.getString("Ganador")));
				comps.add(c);
				Main.Competiciones.put(c.getId(), c);
			}
		} catch (SQLException e) {
			System.out.println("No se ha podido leer el dato");
		}
		return comps;
	}

	public void cerrar() {
		if(this.con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

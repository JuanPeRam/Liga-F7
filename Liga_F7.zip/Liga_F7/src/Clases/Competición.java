package Clases;

public class Competici�n {
	//Atributos
	private int Id;
	private String Temporada;
	private String Nombre;
	private String Ganador;
	private final String temp = "21/22";
	//Constructor
	public Competici�n(int num,String tempo,String Nom, String Gan){
		this.Id = num;
		this.Temporada = tempo;
		this.Nombre = Nom;
		this.Ganador = Gan;
	}
	public Competici�n(int num, String nom, String Gan) {
		this.Id = num;
		this.Nombre = nom;
		this.Ganador = Gan;
		this.Temporada = temp;
	}
	public Competici�n(int num, String nom) {
		this.Id = num;
		this.Nombre = nom;
		this.Temporada = temp;
	}
	//M�todos
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getTemporada() {
		return Temporada;
	}
	public void setTemporada(String temporada) {
		Temporada = temporada;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getGanador() {
		return Ganador;
	}
	public void setGanador(String ganador) {
		Ganador = ganador;
	}
	public String toString() {
		String ret = "Nombre: "+this.Nombre+" Temporada: "+this.Temporada;
		if(this.Ganador != null) ret+=" Ganador: "+this.Ganador;
		return ret;
	}
}

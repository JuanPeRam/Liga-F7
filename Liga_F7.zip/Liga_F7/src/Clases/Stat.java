package Clases;

public class Stat {
	//Atributos
	private int Goles;
	private int Amarillas;
	private int Rojas;
	private Jugador j;
	private Partido p;
	//Constructoes
	public Stat(int g,Jugador j,Partido p) {
		Goles = g;
		this.j = j;
		this.p = p;
	}
	public Stat(int g, int amarilla, int roja,Jugador j, Partido p) {
		Goles = g;
		this.j = j;
		this.p = p;
		this.Amarillas = amarilla;
		this.Rojas = roja;
	}
	//M�todos
	public int getGoles() {
		return Goles;
	}
	public void setGoles(int goles) {
		Goles = goles;
	}
	public int getAmarillas() {
		return Amarillas;
	}
	public void setAmarillas(int amarillas) {
		Amarillas = amarillas;
	}
	public int getRojas() {
		return Rojas;
	}
	public void setRojas(int rojas) {
		Rojas = rojas;
	}
	public Jugador getJ() {
		return j;
	}
	public void setJ(Jugador j) {
		this.j = j;
	}
	public Partido getP() {
		return p;
	}
	public void setP(Partido p) {
		this.p = p;
	}
	public String toString() {
		return "Partido: "+p.getId()+" Jugador: "+j.getNombre()+" Goles: "+Goles+" Amarillas: "+Amarillas+" Rojas: "+Rojas+"\n";
	}
	
}

package Clases;

public class Stat {
	//Atributos
	private int Goles;
	private int Amarillas;
	private int Rojas;
	private Jugador j;
	private Partido p;
	private Competici�n c;
	//Constructoes
	public Stat(int g,Jugador j,Partido p, Competici�n c) {
		Goles = g;
		this.j = j;
		this.p = p;
		this.c = c;
	}
	public Stat(int g, int amarilla, int roja,Jugador j, Partido p, Competici�n c) {
		Goles = g;
		this.j = j;
		this.p = p;
		this.c = c;
		this.Amarillas = amarilla;
		this.Rojas = roja;
	}
	//M�todos
	public int getGoles() {
		return Goles;
	}
	public void setGoles(int goles) {
		Goles = goles;
	}
	public int getAmarillas() {
		return Amarillas;
	}
	public void setAmarillas(int amarillas) {
		Amarillas = amarillas;
	}
	public int getRojas() {
		return Rojas;
	}
	public void setRojas(int rojas) {
		Rojas = rojas;
	}
	public Jugador getJ() {
		return j;
	}
	public void setJ(Jugador j) {
		this.j = j;
	}
	public Partido getP() {
		return p;
	}
	public void setP(Partido p) {
		this.p = p;
	}
	public Competici�n getC() {
		return c;
	}
	public void setC(Competici�n c) {
		this.c = c;
	}
	
	public String toString() {
		return "Partido: "+p.getId()+" Competici�n: "+c.getNombre()+" Jugador: "+j.getNombre()+" Goles: "+Goles+" Amarillas: "+Amarillas+" Rojas: "+Rojas+"\n";
	}
	
}

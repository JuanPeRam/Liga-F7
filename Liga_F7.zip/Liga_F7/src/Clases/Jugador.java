package Clases;

public class Jugador {
	//Atributos
	private int id;
	private String nombre;
	private Equipo e;
	private String temporada;
	//Constructor
	public Jugador(int i, String n, Equipo e, String t) {
		id=i;
		nombre=n;
		this.e=e;
		temporada = t;
	}
	//M�todos
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Equipo getE() {
		return e;
	}
	public void setE(Equipo e) {
		this.e = e;
	}
	public String getTemporada() {
		return temporada;
	}
	public void setTemporada(String temporada) {
		this.temporada = temporada;
	}
	
	public String toString() {
		return "ID: "+this.id+" Nombre: "+this.nombre+" Equipo: "+this.e.getNombre();
	}
	
}

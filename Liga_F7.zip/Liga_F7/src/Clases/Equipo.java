package Clases;

public class Equipo {
	//Atributos
	private String nombre;
	private String procedencia;
	//Constructor
	public Equipo(String nom, String procedencia){
		this.nombre = nom;
		this.procedencia = procedencia;
	}
	//M�todos
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getProcedencia() {
		return procedencia;
	}
	public void setProcedencia(String procedencia) {
		this.procedencia = procedencia;
	}
	public String toString() {
		return "Nombre: "+nombre+" Procedencia: "+procedencia;
	}
	public boolean equals(Object e) {
		if(this.nombre.equals(((Equipo) e).getNombre())) return true;
		else return false;
	}
	
}

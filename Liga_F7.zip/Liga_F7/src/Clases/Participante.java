package Clases;

public class Participante {
	//Atributos
	private Equipo Equipo;
	private Competici�n Competici�n;
	//Contructor
	public Participante(Equipo e, Competici�n c) {
		this.Equipo = e;
		this.Competici�n = c;
	}
	//M�todos
	public Equipo getEquipo() {
		return Equipo;
	}
	public void setEquipo(Equipo equipo) {
		Equipo = equipo;
	}
	public Competici�n getCompetici�n() {
		return Competici�n;
	}
	public void setCompetici�n(Competici�n competici�n) {
		Competici�n = competici�n;
	}
	
	
}

package Clases;

public class Partido {
	//Atributos
	private int id;
	private int jornada;
	private Competici�n Competici�n;
	private Equipo Equipo_Local;
	private Equipo Equipo_Visitante;
	//Constructor
	public Partido(int i, int j, Competici�n c, Equipo el, Equipo ev) {
		id=i;
		jornada=j;
		Competici�n=c;
		Equipo_Local = el;
		Equipo_Visitante = ev;
	}
	//M�todos
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getJornada() {
		return jornada;
	}
	public void setJornada(int jornada) {
		this.jornada = jornada;
	}
	public Competici�n getCompetici�n() {
		return Competici�n;
	}
	public void setCompetici�n(Competici�n competici�n) {
		Competici�n = competici�n;
	}
	public Equipo getEquipo_Local() {
		return Equipo_Local;
	}
	public void setEquipo_Local(Equipo equipo_Local) {
		Equipo_Local = equipo_Local;
	}
	public Equipo getEquipo_Visitante() {
		return Equipo_Visitante;
	}
	public void setEquipo_Visitante(Equipo equipo_Visitante) {
		Equipo_Visitante = equipo_Visitante;
	}
	public String toString() {
		return this.Equipo_Local.getNombre()+" VS "+this.Equipo_Visitante.getNombre()+" ("+this.Competici�n.getNombre()+")";
	}
	
}

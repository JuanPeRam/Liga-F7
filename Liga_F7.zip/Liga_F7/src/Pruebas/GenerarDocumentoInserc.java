package Pruebas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import Clases.Competici�n;
import Clases.Equipo;
import Clases.Jugador;
import Clases.Participante;
import Clases.Partido;
import Clases.Stat;

public class GenerarDocumentoInserc {
	
	private BufferedReader br;
	private BufferedWriter wr;
	public static HashMap<Integer,String> clases = new HashMap<>();
	
	public GenerarDocumentoInserc() {
		rellenaClases();
		ArrayList<String> lineas = new ArrayList<>();
		String linea;
		try {
			br = new BufferedReader(new FileReader("src/ficheros/inserts.sql"));
			linea = br.readLine();
			while(linea!=null) {
				lineas.add(linea);
				String[] eqs = linea.split("\"");
				rellenaArrays(eqs);
				linea = br.readLine();
			}
			wr = new BufferedWriter(new FileWriter("src/ficheros/inserts.sql"));
			for(int i=0;i<lineas.size();i++) {
				wr.write(lineas.get(i)+"\n");
			}
		} catch (FileNotFoundException e) {
			System.out.println("No se encontr� el archivo");
		} catch (IOException e) {
			System.out.println("Error de E/S");
		}
	}
	
	private void rellenaClases() {
		clases.put(1, "Equipos");
		clases.put(2, "Competiciones");
		clases.put(3, "Participantes");
		clases.put(4, "Jugadores");
		clases.put(5, "Partidos");
		clases.put(6, "Stats");
	}
	
	private void rellenaArrays(String[] linea) {
		for(int i=1;i<=clases.size();i++) {
			if(linea[0].indexOf(clases.get(i)) != -1) {
				nuevaLinea(clases.get(i),linea);
			}
		}
	}
	
	private void nuevaLinea(String s, String[] l) {
		switch(s) {
		case "Equipos":	Equipo e = new Equipo(l[1],l[3]);
						Main.Equipos.put(e.getNombre(),e);
						break;
		case "Competiciones": Competici�n c = new Competici�n(Integer.parseInt(l[1]),l[3],l[5],Main.Equipos.get(l[7]));
						Main.Competiciones.put(c.getId(), c);
						break;
		case "Jugadores":
						Jugador j = new Jugador(Integer.parseInt(l[1]),l[5],Main.Equipos.get(l[7]),l[3]);
						Main.Jugadores.put(j.getId(), j);
						break;
		case "Partidos":
						Partido p = new Partido(Integer.parseInt(l[1]),Integer.parseInt(l[3]),Main.Competiciones.get(Integer.parseInt(l[5])),Main.Equipos.get(l[7]),Main.Equipos.get(l[9]),Integer.parseInt(l[11]));
						Main.Partidos.put(p.getId(), p);
						break;
		case "Stats":
						Stat st = new Stat(Integer.parseInt(l[1]),Integer.parseInt(l[3]),Integer.parseInt(l[5]),Main.Jugadores.get(Integer.parseInt(l[7])),Main.Partidos.get(Integer.parseInt(l[9])));
						Main.Stats.add(st);
						break;
		}				
	}
	public void close() {
		if(br!=null && wr != null) {
			try {
				br.close();
				wr.close();
			} catch (IOException e) {
				System.out.println("Error de E/S");
			}
		}
	}
	/**
	 * Funci�n que escribe en un fichero la sentencia para insertar datos en la base de datos
	 * @param opc Opci�n
	 */
	public void EscribirInsert(int opc) {
		String tabla = null;
		String str = "INSERT INTO ";
		switch(opc) {
		case 1: tabla = "Equipos";
				Equipo e = Main.crearEquipo();
				str +=tabla+" VALUES (\""+e.getNombre()+"\",\""+e.getProcedencia()+"\");\n";
				break;
		case 2: tabla = "Competiciones";
				Competici�n c = Main.crearCompeticion();
				str+=tabla+" VALUES (\""+c.getId()+"\",\""+c.getNombre()+"\",\""+c.getTemporada()+"\",\""+c.getGanador().getNombre()+"\");\n";
				break;
		case 3: tabla = "Participan";
				Equipo eqp = Main.seleccionaEquipo();
				for(int i=0;i<3;i++) {
					Participante p = Main.crearParticipanteRec(eqp);
					str = "INSERT INTO Participan VALUES (\""+p.getEquipo().getNombre()+"\",\""+p.getCompetici�n().getId()+"\");\n";
					try {
						wr.write(str);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				break;
		case 4: tabla = "Jugadores";
				Jugador j = Main.crearJugador();
				str+=tabla+" VALUES (\""+j.getId()+"\",\""+j.getTemporada()+"\",\""+j.getNombre()+"\",\""+j.getE().getNombre()+"\");\n";
				break;
		case 5: tabla = "Partidos";
				Partido par = Main.crearPartido();
				str+=tabla+" VALUES (\""+par.getId()+"\",\""+par.getJornada()+"\",\""+par.getCompetici�n().getId()+"\",\""+par.getEquipo_Local().getNombre()+"\",\""+par.getEquipo_Visitante().getNombre()+"\",\""+par.getCampo()+"\");\n";
				Main.Partidos.put(par.getId(), par);
				try {
					wr.write(str);
				} catch (IOException e2) {
					System.out.println("Error");
				}
				for(int k : Main.Jugadores.keySet()) {
					if((Main.Jugadores.get(k).getE() == par.getEquipo_Local() || Main.Jugadores.get(k).getE() == par.getEquipo_Visitante())) {	
						int pr = Main.jugo(Main.Jugadores.get(k));
						if(pr > 0) {
							if(pr ==1) {
								Stat s = Main.crearStatsRec(par,Main.Jugadores.get(k));
								str = "INSERT INTO Stats VALUES (\""+s.getGoles()+"\",\""+s.getAmarillas()+"\",\""+s.getRojas()+"\",\""+s.getJ().getId()+"\",\""+s.getP().getId()+"\");\n";
							}
							else {
								str = "INSERT INTO Stats VALUES (\"0\",\"0\",\"0\",\""+Main.Jugadores.get(k).getId()+"\",\""+par.getId()+"\");\n";
							}
						try {
							wr.write(str);
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						}
					}
				}
				break;
		case 6: tabla = "Jugadores";
				Equipo eq = Main.seleccionaEquipo();
				do {
					Jugador jug = Main.crearJugadorRec(eq);
					str = "INSERT INTO Jugadores VALUES (\""+jug.getId()+"\",\""+jug.getTemporada()+"\",\""+jug.getNombre()+"\",\""+jug.getE().getNombre()+"\");\n";
					try {
						wr.write(str);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					Main.Jugadores.put(jug.getId(), jug);
				}while(Main.continuar());
				break;
				
		default: System.out.println("Opci�n inv�lida");
		}
		try {
			if(opc!=5 && opc !=6 && opc!=3) wr.write(str);
		} catch (IOException e1) {
			System.out.println("Error de entrada/salida");
		}
	}
	
	public void escribirInsertArrayEquipos() {
		for(String clave: Main.Equipos.keySet()) {
			String st = "INSERT INTO Equipos VALUES (\""+Main.Equipos.get(clave).getNombre()+"\",\""+Main.Equipos.get(clave).getProcedencia()+"\");\n";
			try {
				wr.write(st);
			} catch (IOException e) {
				System.out.println("Error1");
			}
		}
	}
	
	public void escribirInsertArrayCompeticiones() {
		for(int clave: Main.Competiciones.keySet()) {
			String st = "INSERT INTO Competiciones VALUES (\""+Main.Competiciones.get(clave).getId()+"\",\""+Main.Competiciones.get(clave).getTemporada()+"\",\""
					+Main.Competiciones.get(clave).getNombre()+"\",\""+Main.Competiciones.get(clave).getGanador().getNombre()+"\");\n";
			try {
				wr.write(st);
			} catch (IOException e) {
				System.out.println("Error2");
			}
		}
		try {
			wr.write("\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void escribirInsertArrayJugadores() {
		for(int clave: Main.Jugadores.keySet()) {
			String st = "INSERT INTO Jugadores VALUES (\""+Main.Jugadores.get(clave).getId()+"\",\""+Main.Jugadores.get(clave).getNombre()
					+"\",\""+Main.Jugadores.get(clave).getE().getNombre()+"\",\""+Main.Jugadores.get(clave).getTemporada()+"\");\n";
		try {
			wr.write(st);
		} catch (IOException e) {
			System.out.println("Error");
		}
		}
		try {
			wr.write("\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

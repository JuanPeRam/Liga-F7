package Pruebas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import Clases.Equipo;

public class GenerarDocumentoInserc {
	
	BufferedReader br;
	BufferedWriter wr;
	
	public GenerarDocumentoInserc() {
		try {
			br = new BufferedReader(new FileReader("src/ficheros/inserts.sql"));
			wr = new BufferedWriter(new FileWriter("src/ficheros/inserts.sql"));
		} catch (FileNotFoundException e) {
			System.out.println("No se encontr� el archivo");
		} catch (IOException e) {
			System.out.println("Error de E/S");
		}
	}
	public void close() {
		if(br!=null && wr != null) {
			try {
				br.close();
				wr.close();
			} catch (IOException e) {
				System.out.println("Error de E/S");
			}
		}
	}
	/**
	 * Funci�n que escribe en un fichero la sentencia para insertar datos en la base de datos
	 * @param e Equipo a insertar
	 */
	public void EscribirInsertEquipo(Equipo e) {
		String str = "INSERT INTO EQUIPOS VALUES (\""+e.getNombre()+"\",\""+e.getProcedencia()+"\");\n";
		try {
			wr.write(str);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}

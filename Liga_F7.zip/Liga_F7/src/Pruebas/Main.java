package Pruebas;

import java.util.Scanner;

import Clases.Equipo;
import inserci�n.EquiposDAO;

public class Main {
	private static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args) {
		EquiposDAO eDAO = new EquiposDAO();
		GenerarDocumentoInserc gd = new GenerarDocumentoInserc();
		int opc;
		printMenu();
		opc = in.nextInt();
		while(opc!=0) {
			switch(opc) {
			case 1:	gd.EscribirInsertEquipo(crearEquipo());break;
			default: break;
			}
		printMenu();
		opc = in.nextInt();
		}
		gd.close();
	}

	private static Equipo crearEquipo() {
		Equipo e;
		String nom,proc;
		in.nextLine();
		System.out.println("Introduzca el nombre del equipo: ");
		nom = in.nextLine();
		System.out.println("Introduzca su procedencia: ");
		proc = in.nextLine();
		e = new Equipo(nom,proc);
		return e;
	}

	private static void printMenu() {
		System.out.println("Escoja una opci�n: ");
		System.out.println("1 - INSERTAR NUEVO EQUIPO");
		System.out.println("2 - BORRAR EQUIPO");
		System.out.println("(0 SALIR)");
		
	}

}

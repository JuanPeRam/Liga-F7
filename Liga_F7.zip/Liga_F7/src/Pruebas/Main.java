package Pruebas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Clases.Competici�n;
import Clases.Equipo;
import Clases.Jugador;
import Clases.Participante;
import Clases.Partido;
import Clases.Stat;
import inserci�n.CompeticionesDAO;
import inserci�n.EquiposDAO;
import inserci�n.Funciones;
import inserci�n.JugadoresDAO;

public class Main {
	private static Scanner in = new Scanner(System.in);
	public static HashMap<String,Equipo> Equipos = new HashMap<>();
	public static HashMap<Integer,Competici�n> Competiciones = new HashMap<>();
	public static HashMap<Integer,Jugador> Jugadores = new HashMap<>();
	public static HashMap<Integer, Partido> Partidos = new HashMap<>();
	public static ArrayList<Stat> Stats = new ArrayList<>();
	
	public static void main(String[] args) {
		EquiposDAO eDAO = new EquiposDAO();
		eDAO.readAll();
		CompeticionesDAO cDAO = new CompeticionesDAO();
		GenerarDocumentoInserc gd = new GenerarDocumentoInserc();
		JugadoresDAO jDAO = new JugadoresDAO();
		cDAO.readAll();
		jDAO.readAll();
		int opc;
		printMenu();
		opc = in.nextInt();
		while(opc!=0) {
			gd.EscribirInsert(opc);
			printMenu();
		opc = in.nextInt();
		}
		System.out.println(Competiciones);
		System.out.println(Equipos);
		System.out.println(Jugadores);
		System.out.println(Partidos);
		System.out.println(Stats);
		eDAO.cerrar();
		cDAO.cerrar();
		gd.close();
		jDAO.cerrar();
		eDAO.cerrar();
	}

	public static Equipo crearEquipo() {
		Equipo e;
		String nom,proc;
		in.nextLine();
		System.out.println("Introduzca el nombre del equipo: ");
		nom = in.nextLine();
		System.out.println("Introduzca su procedencia: ");
		proc = in.nextLine();
		e = new Equipo(nom,proc);
		Equipos.put(e.getNombre(), e);
		return e;
	}

	private static void printMenu() {
		System.out.println("Escoja una opci�n: ");
		System.out.println("1 - INSERTAR NUEVO EQUIPO");
		System.out.println("2 - INSERTAR NUEVA COMPETICI�N");
		System.out.println("3 - INSERTAR NUEVO COMPETIDOR");
		System.out.println("4 - INSERTAR NUEVO JUGADOR");
		System.out.println("5 - INSERTAR NUEVO PARTIDO");
		System.out.println("6 - RELLENAR JUGADORES DE UN EQUIPO");
		System.out.println("(0 SALIR)");
		
	}

	public static Competici�n crearCompeticion() {
		Competici�n c = null;
		String temporada;
		String nom;
		String nom_ganador;
		Equipo e = null;
		int opc;
		in.nextLine();
		System.out.println("Introduzca el nombre de la Competici�n: ");
		nom = in.nextLine();
		System.out.println("Introduzca la temporada: ");
		temporada = in.nextLine();
		System.out.println("�Introducir ganador (1 s�, 0 no)?");
		opc = in.nextInt();
		in.nextLine();
		if(opc==1) {
			System.out.println("Introduzca el nombre del ganador");
			nom_ganador = in.nextLine();
			e = Equipos.get(nom_ganador);
		}
		c = new Competici�n((Competiciones.size()+1),nom,temporada,e);
		Competiciones.put(c.getId(), c);
		return c;
	}
	
	public static Participante crearParticipante() {
		String nombre_equipo;
		int id_competicion;
		in.nextLine();
		System.out.println("Introduzca el nombre del Equipo: ");
		nombre_equipo = in.nextLine();
		System.out.println("Introduzca el id de la Competici�n");
		mostrarCompeticiones();
		id_competicion = in.nextInt();
		Participante p = new Participante(Equipos.get(nombre_equipo),Competiciones.get(id_competicion));
		return p;
	}
	
	private static void mostrarCompeticiones() {
		System.out.println("---------------Competiciones----------------");
		for(int i=1; i<Competiciones.size()+1;i++) {
			System.out.println(Competiciones.get(i).getId()+" | "+Competiciones.get(i).getNombre());
		}
		System.out.println("--------------------------------------------");
	}

	public static Jugador crearJugador() {
		String nombre;
		String temporada;
		String nombre_equipo;
		in.nextLine();
		System.out.println("Introduzca el nombre del jugador: ");
		nombre = in.nextLine();
		System.out.println("Introduzca el nombre del equipo: ");
		nombre_equipo = in.nextLine();
		System.out.println("Introduzca la temporada: ");
		temporada = in.nextLine();
		Jugador j = new Jugador(Jugadores.size()+1,nombre,Equipos.get(nombre_equipo),temporada);
		return j;
	}
	
	public static Partido crearPartido() {
		int id_competicion;
		String eL;
		String eV;
		int jornada;
		int campo;
		System.out.println("Introduzca el id de la Competici�n: ");
		mostrarCompeticiones();
		id_competicion = in.nextInt();
		System.out.println("Introduzca la jornada: ");
		jornada = in.nextInt();
		in.nextLine();
		System.out.println("Introduzca el campo: ");
		campo = in.nextInt();
		in.nextLine();
		System.out.println("Introduzca el nombre del Equipo Local: ");
		eL = in.nextLine();
		System.out.println("Introduzca el nombre del Equipo Visitante: ");
		eV = in.nextLine();
		Partido p = new Partido(Partidos.size()+1,jornada,Competiciones.get(id_competicion),Equipos.get(eL),Equipos.get(eV),campo);
		return p;
	}

	public static Stat crearStatsRec(Partido p, Jugador j) {
		int goles;
		int amarilla,roja;
		System.out.println("Goles anotados: ");
		goles = in.nextInt();
		System.out.println("Amarillas: ");
		amarilla = in.nextInt();
		System.out.println("Rojas: ");
		roja = in.nextInt();
		Stat s = new Stat(goles,amarilla,roja,j,p);
		return s;
	}

	private static void printJugadores(Equipo equipo) {
		for(int i=0;i<Jugadores.size();i++) {
			if(Jugadores.get(i).getE() == equipo) {
				System.out.println(Jugadores.get(i));
			}
		}
	}

	public static boolean continuar() {
		int cont;
		System.out.println("�Desea continuar? (1 s�, 0 no)");
		cont = in.nextInt();
		if(cont == 1) return true;
		else return false;
	}

	public static Equipo seleccionaEquipo() {
		System.out.println("Seleccione Equipo: ");
		printEquipos();
		String e = in.nextLine();
		return Equipos.get(e);
	}
	
	public static void printEquipos() {
		System.out.println("-----------Equipos-----------");
		for(String e : Equipos.keySet()) {
			System.out.println(Equipos.get(e).getNombre());
		}
		System.out.println("-----------------------------");
	}

	public static Jugador crearJugadorRec(Equipo eq) {
		String nombre;
		String temporada;
		in.nextLine();
		System.out.println("Introduzca el nombre del jugador: ");
		nombre = in.nextLine();
		temporada = "21/22";
		Jugador j = new Jugador(Jugadores.size()+1,nombre,Equipos.get(eq.getNombre()),temporada);
		return j;
	}

	public static Participante crearParticipanteRec(Equipo e) {
		String nombre_equipo = e.getNombre();
		int id_competicion;
		System.out.println("Introduzca el id de la Competici�n");
		mostrarCompeticiones();
		id_competicion = in.nextInt();
		Participante p = new Participante(Equipos.get(nombre_equipo),Competiciones.get(id_competicion));
		return p;
	}

	public static int jugo(Jugador jugador) {
		System.out.println("Jugador :"+jugador.getNombre());
		System.out.println("�Jug� el partido? (1 s� 0 no 2 jug� pero nanai)");
		int n = in.nextInt();
		if(n>=0 && n<=2) return n;
		else return 0;
	}

}
